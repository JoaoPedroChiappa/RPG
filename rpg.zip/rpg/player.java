import java.rmi.StubNotFoundException;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

public class player {

    dados dados = new dados();
    monstro monstro = new monstro();

    private Scanner respostaPlayer = new Scanner(System.in);
    
    //inicio atributos
    public String nome = "ChP";
    public String classe = "Knight";
    public int vida = 100;
    public int ataque = 5;
    public int defesa = 10;
    //fim atributos
    
    //atacar + dano
    public void atacar() throws InterruptedException{
        String resposta;
        char r;

        System.out.println("Voce quer atacar? (S) / (N)");
        resposta = respostaPlayer.next();
        r = resposta.toUpperCase().charAt(0);

        if (r == 'S'){
            
            int valorTentativa = dados.RolarDado20();
            System.out.println("Valor do D-20: " + valorTentativa);

            if(valorTentativa > monstro.defesa){
                System.out.println("Voce consegue atacar!");
                TimeUnit.SECONDS.sleep(2);
                int valorDano = dados.RolarDado10();
                System.out.println("Valor do D-10: " + valorDano);
                System.out.println("Voce deu " + (valorDano + ataque) + " de dano.");
            }else if(valorTentativa == 1 /* erro crítico */){
                System.out.println("O ataque deu errado...");
                System.out.println("E vc vai ser atacado(a)");
                TimeUnit.SECONDS.sleep(2);
                monstro.atacar();
            }else{
                System.out.println("O ataque deu errado.");
            }

        }else if(r == 'N'){
            System.out.println("Voce não quis atacar.");
        }

    }

}
