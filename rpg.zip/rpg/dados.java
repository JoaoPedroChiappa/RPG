import java.util.Random;

public class dados{

    //Rolar D-10
    public int RolarDado10(){

        Random numero = new Random();   
            
        int result = numero.nextInt(1, 11);

        return result;

    }

    //Rolar D-20
    public int RolarDado20(){

        Random numero = new Random();   
            
        int result = numero.nextInt(1, 21);

        return result;

    }
    
}