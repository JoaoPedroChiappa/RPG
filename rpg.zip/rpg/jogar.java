public class jogar {
 
    public static void main(String[] args) throws Exception {

        player player = new player();
        monstro monstro = new monstro();

        player.atacar();

        if (monstro.vida <= 0){
            System.out.println("Parabéns, vc derrotou " + monstro.nome + "!");
        }else{
            System.out.println("Você morreu...");
        }

    }

}