public class jogar {
 
    public static void main(String[] args) throws Exception {

        player player = new player();
        monstro monstro = new monstro();

        int PlayerVida = player.vida;
        int MonstroVida = monstro.vida;

        int turno = 1;

        while (MonstroVida > 0 && PlayerVida > 0){
            
            if(turno == 1){
                System.out.println();
                System.out.println("================================================================ PLAYER =================================================================");
                System.out.println("Vida player: " + PlayerVida + "                " + "Vida monstro: " + MonstroVida);
                
                player.atacar();

                if(player.confirmaAtaque == true){
                    int danoCausado = player.getDanoCausado();
                    MonstroVida = MonstroVida - danoCausado;
                }
                
                turno = 2;
            }else{
                System.out.println();
                System.out.println("================================================================ MONSTRO =================================================================");
                System.out.println("Vida player: " + PlayerVida + "                " + "Vida monstro: " + MonstroVida);
                
                monstro.atacar();
                
                if(monstro.confirmaAtaque == true){
                    int danoCausado = monstro.getDanoCausado();
                    PlayerVida = PlayerVida - danoCausado;
                }

                turno = 1;
            }
            
        }

        System.out.println("================================================================ FIM DE JOGO =================================================================");
        System.out.println("Vida player: " + PlayerVida + "                " + "Vida monstro: " + MonstroVida);

        if (MonstroVida <= 0){
            MonstroVida = 0;
            System.out.println("Parabéns, vc derrotou " + monstro.nome + "!");
        }else if(PlayerVida <= 0){
            PlayerVida = 0;
            System.out.println("Você morreu...");
        }

    }

}