import java.sql.Time;
import java.util.concurrent.TimeUnit;

public class monstro {

    dados dados = new dados();
    player player = new player();
    
    //inicio atributos
    public String nome = "Archdevil";
    public String classe = "Demonio";
    public int vida = 1000;
    public int ataque = 5;
    public int defesa = 12;
    //fim atributos
    
    //atacar + dano
    public void atacar() throws InterruptedException{

        int valorTentativa = dados.RolarDado20();

        if(valorTentativa > player.defesa){
            System.out.println("Voce consegue atacar!");
            int valorDano = dados.RolarDado10();
            valorDano = valorDano + ataque;
            System.out.println(nome + " deu " + valorDano + " de dano.");
            player.vida = player.vida - valorDano; //vida do player
        }else if(valorTentativa == 1 /* erro crítico */){
            System.out.println("O ataque de " + nome + " deu errado...");
            System.out.println("E vc vai dar um contra-ataque.");
            TimeUnit.SECONDS.sleep(2);
            player.atacar();
        }else{
            System.out.println("O ataque deu errado.");
        }

    }

}