import java.util.concurrent.TimeUnit;

public class monstro {

    //inicio atributos
    public String nome = "Archdevil";
    public String classe = "Demonio";
    public int vida = 100;
    public int ataque = 4;
    public int defesa = 12;
    //fim atributos

    public int danoTotal;
    public boolean confirmaAtaque;
    
    //atacar + dano
    public void atacar() throws InterruptedException{

        dados dados = new dados();
        player player = new player();

        int valorTentativa = dados.RolarDado20();

        if(valorTentativa > player.defesa){
            System.out.println(nome + " consegue atacar!");
            TimeUnit.SECONDS.sleep(2);

            int valorDano = dados.RolarDado10();
            danoTotal = valorDano + ataque;
            confirmaAtaque = true;

            System.out.println(nome + " deu " + danoTotal + " de dano.");

        }else if(valorTentativa == 1 /* erro crítico */){
            System.out.println("O ataque de " + nome + " deu errado...");
            System.out.println("E vc vai dar um contra-ataque.");
            confirmaAtaque = false;
            TimeUnit.SECONDS.sleep(2);
            player.atacar();
        }else{
            System.out.println("O ataque de " + nome + " deu errado.");
            confirmaAtaque = false;
        }

    }

    public int getDanoCausado() {
        return danoTotal;
    }

}